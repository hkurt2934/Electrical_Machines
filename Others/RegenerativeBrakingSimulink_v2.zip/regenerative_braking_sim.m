
% Regenerative Braking Simulation with Bidirectional Inverter
% Author: Research Assistant
% Description: Configure and run a simplified regenerative braking model

% Load model
model = 'regenerative_braking_model';
load_system(model);

% Set simulation parameters
set_param([model '/Vehicle Dynamics'], 'Mass', '1500');
set_param([model '/Motor'], 'MotorType', 'PMSM');
set_param([model '/Battery'], 'NominalVoltage', '400');
set_param([model '/Bidirectional Inverter'], 'SwitchingFrequency', '10000');

% Run simulation
simOut = sim(model);

% Plot battery SOC change
figure;
plot(simOut.tout, simOut.logsout.getElement('BatterySOC').Values.Data);
xlabel('Time (s)');
ylabel('Battery SOC (%)');
title('Battery SOC during Regenerative Braking');
grid on;
